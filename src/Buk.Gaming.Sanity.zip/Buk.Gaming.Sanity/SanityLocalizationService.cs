﻿using Buk.Gaming.Providers;
using Buk.Gaming.Sanity.Models;
using Microsoft.Extensions.Caching.Memory;
using Sanity.Linq;
using Sanity.Linq.Extensions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Buk.Gaming.Sanity
{

    public class CachedSanityLocalizationService : SanityLocalizationService
    {
        private IMemoryCache _cache { get; }

        public CachedSanityLocalizationService(SanityDataContext sanity, SanityOptions options, IMemoryCache cache, IImageService imageSvc) : base(sanity, options, imageSvc)
        {
            _cache = cache;
        }


        public override Task<object> GetJsonAsync(string lang, string module = "")
        {
            return _cache.GetOrCreateAsync("SANITY_LOCALIZATION_" + (lang ?? "") + "_" + (module ?? ""), (c) =>
            {
                c.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(60);
                return base.GetJsonAsync(lang, module);
            });
        }
    }

    public class SanityLocalizationService : ILocalizationService
    {
        private SanityDataContext _sanity { get; }

        public SanityLocalizationService(SanityDataContext sanity, SanityOptions options, IImageService imageService)
        {
            _sanity = sanity;
        }

        public virtual async Task<object> GetJsonAsync(string lang, string module = "")
        {
            var localizations = await GetLocalizationsAsync().ConfigureAwait(false);
            if (localizations.ContainsKey(lang.ToLower()))
            {
                var languageLocalizations = localizations[lang.ToLower()];

                var root = new Dictionary<string, object>();
                foreach (var loc in languageLocalizations)
                {
                    var code = loc.Key;
                    var parts = code.Split('.');
                    Dictionary<string, object> currentNode = root;
                    for (int i = 0; i < parts.Length - 1; i++)
                    {
                        if (!currentNode.ContainsKey(parts[i]) || !(currentNode[parts[i]] is Dictionary<string, object>))
                        {
                            currentNode[parts[i]] = new Dictionary<string, object>();
                        }
                        currentNode = currentNode[parts[i]] as Dictionary<string, object>;
                    }
                    currentNode[parts[parts.Length - 1]] = loc.Value;
                }

                return root;
            }

            // Default: empty object
            return new object();
        }

        public async Task<Dictionary<string, Dictionary<string, string>>> GetLocalizationsAsync()
        {
            var localizations = await _sanity.DocumentSet<SanityLocalization>().ToListAsync().ConfigureAwait(false);
            var localizationBlocks = await _sanity.DocumentSet<SanityLocalizationBlock>().ToListAsync().ConfigureAwait(false);

            var result = new Dictionary<string, Dictionary<string, string>>();
            result["en"] = new Dictionary<string, string>();
            result["no"] = new Dictionary<string, string>();
            result["it"] = new Dictionary<string, string>();


            // Localization Strings //
            foreach (var localization in localizations)
            {
                foreach (var lang in result.Keys)
                {
                    var code = (localization.Code?.Current ?? "").Trim();
                    if (code != "")
                    {
                        var value = localization[lang];
                        if (string.IsNullOrEmpty(value))
                        {
                            value = localization["no"];
                        }
                        if (string.IsNullOrEmpty(value))
                        {
                            value = localization["en"];
                        }
                        if (string.IsNullOrEmpty(value))
                        {
                            value = localization["it"];
                        }
                        result[lang][code] = value;
                    }
                }
            }


            // Localization Blocks //
            foreach (var localization in localizationBlocks)
            {
                foreach (var lang in result.Keys)
                {
                    var code = (localization.Code?.Current ?? "").Trim();
                    if (code != "")
                    {
                        var value = localization[lang]?.ToHtml(_sanity);
                        if (string.IsNullOrEmpty(value))
                        {
                            value = localization["no"]?.ToHtml(_sanity);
                        }
                        if (string.IsNullOrEmpty(value))
                        {
                            value = localization["en"]?.ToHtml(_sanity);
                        }
                        if (string.IsNullOrEmpty(value))
                        {
                            value = localization["it"]?.ToHtml(_sanity);
                        }
                        result[lang][code] = value ?? "";
                    }
                }
            }

            return result;

        }
    }
}
